var searchData=
[
  ['leer',['leer',['../classtabla.html#ab297ddbd500d85a98d7c801697b73721',1,'tabla']]]
];
