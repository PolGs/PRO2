var searchData=
[
  ['size',['size',['../classtabla.html#ade5cabea713c5247052a4ea28462945d',1,'tabla']]]
];
