var searchData=
[
  ['idioma',['idioma',['../classidioma.html',1,'']]]
];
