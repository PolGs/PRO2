var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar',['modificar',['../classtabla.html#a37f915651b80eaa0c6dc47c23ff92557',1,'tabla']]],
  ['modificar_5fidioma',['modificar_idioma',['../classcjt__idioma.html#ac9cdce411a32c42a9fc7da848f7de4c0',1,'cjt_idioma::modificar_idioma()'],['../classidioma.html#af7d4b2d6a05e6b87783d9394fb1cc08e',1,'idioma::modificar_idioma()']]]
];
