var searchData=
[
  ['idioma',['idioma',['../classidioma.html',1,'idioma'],['../classidioma.html#aef8714e17b1c5141104f5fb7bd989283',1,'idioma::idioma()']]],
  ['idioma_2ehh',['idioma.hh',['../idioma_8hh.html',1,'']]]
];
