var searchData=
[
  ['idioma',['idioma',['../classidioma.html#aef8714e17b1c5141104f5fb7bd989283',1,'idioma']]]
];
