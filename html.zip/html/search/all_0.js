var searchData=
[
  ['anadir_5fidioma',['anadir_idioma',['../classcjt__idioma.html#aaf8acea2625eb1a72fbeaed23357c4ad',1,'cjt_idioma']]]
];
