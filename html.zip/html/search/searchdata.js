var indexSectionsWithContent =
{
  0: "acdeilmopst",
  1: "cit",
  2: "cipt",
  3: "acdeilmost"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones"
};

