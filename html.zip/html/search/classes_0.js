var searchData=
[
  ['cjt_5fidioma',['cjt_idioma',['../classcjt__idioma.html',1,'']]]
];
